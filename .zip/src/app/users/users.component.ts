import { Component, OnInit } from '@angular/core';
import { UserServiceService } from '../user-service.service'

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  users:any;
  array:any =[];
  //getValue(data:any){
  //    console.log(data)
 // }
  getusers(data:any){
    this.users=data
    console.log(this.users, "receiver got it")
    this.api.getUser(this.users)
    //console.log(this.users, "sending users to service check")
  }
  constructor(private api:UserServiceService) { }
  ngOnInit(): void {
      this.api.apiCall().subscribe((data)=> {
      console.log(data)
      this.array= data;    
    })
      
  }

}
