import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; 
@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  constructor(
    private http:HttpClient
  ) { }
  user:any;
  receiver= 'kanaka';
  apiCall()
  {
    return this.http.get(`http://localhost:3000/userslist`);
  }
   getReceiver(sender:any){
     return this.http.get(`http://localhost:3000/users/chat/id=${this.user}?sender=${sender}`, {responseType: 'json'});
   }
  get user_profile(){
    return localStorage.getItem('users');
  }
  getUser(data:any){
    this.user= data
    console.log(this.user, "receiver at services side")
  }
  sendUser(){
    return this.user
  }

 /* loginUser(username:any, password:any)
  {
    return this.http.post(`http://localhost:3000/loginUser`, {username:username, password:password});
  }*/
  
}
